
# USBCore driver for audio over USB

In order to get the audio over USB working replace driver `USBCore.cpp` located in:


```
home/arjan/.platformio/packages/framework-arduino-samd@1.8.9/cores/arduino/USB/USBCore.cpp
```

with this one.
